---
trigger: always_on
description: MVP scope boundaries and full 49-component build list for Dashboard Link
---

# Dashboard Link — Scope & Build Status

## Scope Gate

Before building anything new:
1. Check the component list below for current status
2. If the feature is not listed — stop and flag it before proceeding
3. Say: "This feature is not in the current build plan. Do you want to add it or skip it?"

Never silently build out-of-scope features.

---

## Component Build List

### Phase 1: MVP (5 components)
| # | Component | Status |
|---|-----------|--------|
| 1 | `worker-management` | ✅ Complete |
| 2 | `token-system` | 🔄 In Progress |
| 3 | `sms-delivery` | 📋 Planned |
| 4 | `worker-dashboard` | 📋 Planned |
| 5 | `access-logging` | 📋 Planned |

### Phase 2: Core Features (11 components)
| # | Component | Status |
|---|-----------|--------|
| 6 | `admin-authentication` | 📋 Planned |
| 7 | `user-onboarding-wizard` | 📋 Planned |
| 8 | `google-calendar-plugin` | 📋 Planned |
| 9 | `manual-entry-plugin` | 📋 Planned |
| 10 | `billing-stripe-integration` | 📋 Planned |
| 11 | `referral-system` | 📋 Planned |
| 12 | `analytics-dashboard` | 📋 Planned |
| 13 | `monthly-value-emails` | 📋 Planned |
| 14 | `powered-by-footer` | 📋 Planned |
| 15 | `dashboard-widget-customisation` | 📋 Planned |
| 16 | `basic-branding` | 📋 Planned |

### Phase 3: Automation (2 components)
| # | Component | Status |
|---|-----------|--------|
| 17 | `scheduled-sms-automation` | 📋 Planned |
| 18 | `queue-processing-bullmq` | 📋 Planned |

### Infrastructure & Deployment (8 components)
| # | Component | Status |
|---|-----------|--------|
| 19 | `local-development-setup` | 🔄 In Progress |
| 20 | `vercel-frontend-deployment` | 📋 Planned |
| 21 | `railway-backend-deployment` | 📋 Planned |
| 22 | `supabase-production-setup` | 📋 Planned |
| 23 | `ci-cd-github-actions` | 📋 Planned |
| 24 | `environment-management` | 📋 Planned |
| 25 | `domain-dns-configuration` | 📋 Planned |
| 26 | `cdn-static-assets` | 📋 Planned |

### Monitoring & Observability (6 components)
| # | Component | Status |
|---|-----------|--------|
| 27 | `sentry-error-tracking` | 📋 Planned |
| 28 | `uptime-monitoring` | 📋 Planned |
| 29 | `performance-monitoring` | 📋 Planned |
| 30 | `logging-infrastructure` | 📋 Planned |
| 31 | `alerting-notifications` | 📋 Planned |
| 32 | `business-analytics-tracking` | 📋 Planned |

### Security & Compliance (5 components)
| # | Component | Status |
|---|-----------|--------|
| 33 | `multi-tenant-isolation` | 🔄 In Progress |
| 34 | `authentication-security` | 📋 Planned |
| 35 | `api-security-hardening` | 📋 Planned |
| 36 | `gdpr-compliance` | 📋 Planned |
| 37 | `incident-response-plan` | 📋 Planned |

### Database & Data Management (4 components)
| # | Component | Status |
|---|-----------|--------|
| 38 | `database-schema-management` | ✅ Complete |
| 39 | `backup-recovery-strategy` | 📋 Planned |
| 40 | `data-seeding` | 📋 Planned |
| 41 | `database-optimization` | 📋 Planned |

### Third-Party Integrations (5 components)
| # | Component | Status |
|---|-----------|--------|
| 42 | `mobilemessage-sms-setup` | 📋 Planned |
| 43 | `stripe-billing-setup` | 📋 Planned |
| 44 | `google-oauth-setup` | 📋 Planned |
| 45 | `notion-oauth-setup` | 📋 Planned |
| 46 | `email-service-setup` | 📋 Planned |

### Testing & Quality (3 components)
| # | Component | Status |
|---|-----------|--------|
| 47 | `testing-strategy` | 📋 Planned |
| 48 | `code-quality-standards` | 📋 Planned |
| 49 | `performance-testing` | 📋 Planned |

---

## What Is Explicitly NOT In Scope (Ever / MVP)

Do not build, suggest, or scaffold any of the following:

- Payroll, time tracking, or HR features
- Worker logins, accounts, or passwords
- In-app messaging or team chat
- Native mobile app (iOS or Android)
- Complex scheduling or shift management
- Invoicing or billing management
- Multi-language support (English only)
- Airtable or Notion plugins (Phase 2 — not MVP)
- Stripe billing (Phase 2 — not MVP)
- Referral system (Phase 2 — not MVP)
- Scheduled automatic SMS (Phase 3 — not MVP)
- BullMQ queue processing (Phase 3 — not MVP)
- Webhook support (Phase 3 — not MVP)
- Custom plugin builder (Phase 3 — not MVP)
- Worker logins or accounts (icebox — never)

## Phase Reference

| Phase | Goal | Timeline |
|-------|------|----------|
| 1 — MVP | 3–5 beta businesses using it over WhatsApp | Months 1–3 |
| 2 — Growth | Paid conversions + referral engine | Months 4–6 |
| 3 — Scale | 12–15 paying customers | Months 7–12 |

## Scope Creep Rule

This is a solo developer build. Every out-of-scope feature added delays the MVP and risks the project. When in doubt — cut it and add to icebox.
