---
trigger: always_on
description: Duplicate file decisions and resolved conflicts for Dashboard Link — read before touching any ambiguous file
---

# Dashboard Link — Conflicts & Resolutions

When two implementations exist, this file decides which one wins.
Read this before touching any file listed here.

---

## Active Resolutions

### 1. Webhook Service — use `webhookService.ts`

| File | Decision | Reason |
|------|----------|--------|
| `apps/api/src/services/webhookService.ts` | ✅ CANONICAL | More complete: queue processing, proper logging, error handling |
| `apps/api/src/services/webhook-service.ts` | ❌ DELETE | Class-based stub, incomplete |

**Action:** Delete `webhook-service.ts` after confirming zero imports remain. Update any `v1.ts` references.

---

### 2. Webhook Route — use `routes/webhooks.ts`

| File | Decision | Reason |
|------|----------|--------|
| `apps/api/src/routes/webhooks.ts` | ✅ CANONICAL | Dedicated routes file, uses correct service |
| Inline webhook block in `routes/v1.ts` | ❌ REMOVE the block | Duplicate; `v1.ts` should register `routes/webhooks.ts` |

**Action:** In `v1.ts`, replace inline webhook handler with:
```typescript
import webhookRoutes from './webhooks'
app.route('/webhooks', webhookRoutes)
```

---

### 3. Column name — `organization_id` not `org_id`

| Version | Decision |
|---------|----------|
| `organization_id` (DATABASE-SCHEMA.md, actual migrations) | ✅ CORRECT |
| `org_id` (old rules files) | ❌ WRONG — those rules files are now replaced |

**All queries use `organization_id`.** If you see `org_id` in application code, it's a bug.

---

### 4. Zod version — 3.x not 4.x

| Version | Decision |
|---------|----------|
| Zod 3.x (TECH-STACK.md — source of truth) | ✅ CORRECT |
| Zod 4.x (old auto-generated specify-rules.md) | ❌ WRONG — that file is deleted |

**Use Zod 3.x.** Import from `'zod'` — version is pinned in package.json.

---

### 5. Project structure — `apps/api/` not `packages/api/`

| Path | Decision |
|------|----------|
| `apps/api/` (FOLDER-STRUCTURE.md — actual codebase) | ✅ CORRECT |
| `packages/api/` (old specify-rules.md) | ❌ WRONG — that file is deleted |

Correct top-level structure: `apps/admin/`, `apps/worker/`, `apps/api/`

---

### 6. SMS and token locations — not separate packages

| Path | Decision |
|------|----------|
| `apps/api/src/services/sms.ts` | ✅ SMS logic lives here |
| `apps/api/src/services/tokens.ts` | ✅ Token logic lives here |
| `packages/sms/` | ❌ Does not exist |
| `packages/tokens/` | ❌ Does not exist |

---

### 7. RLS pattern — session variable, not auth.uid()

| Pattern | Decision |
|---------|----------|
| `current_setting('app.tenant_id', true)::uuid` | ✅ CORRECT — our custom pattern |
| `auth.uid()` or `auth.jwt() ->> 'organization_id'` | ❌ WRONG for this codebase |

Set via `app.tenant_id` session variable in `middleware/tenant.ts` on every request.

---

## Deleted Files

| File | Deleted | Reason |
|------|---------|--------|
| `.windsurf/rules/specify-rules.md` | ✅ | Auto-generated noise: wrong Zod version, wrong paths, no triggers, duplicate lines |
| `apps/api/src/services/webhook-service.ts` | Pending | Superseded by `webhookService.ts` |

---

## How to Add a New Conflict

When you find a duplicate, add it here before asking for a fix:

```markdown
### N. [Module name] — use [winning file]

| File | Decision | Reason |
|------|----------|--------|
| `path/to/winner` | ✅ CANONICAL | Why it wins |
| `path/to/loser`  | ❌ DELETE/REMOVE | Why it loses |

**Action:** What exactly needs to change.
```

## Decision Log

| Date | Conflict | Winner | Reason |
|------|----------|--------|--------|
| 2026-03-16 | webhook-service.ts vs webhookService.ts | webhookService.ts | More complete implementation |
| 2026-03-16 | Duplicate webhook route in v1.ts | routes/webhooks.ts | Separation of concerns |
| 2026-03-16 | org_id vs organization_id | organization_id | Matches actual schema |
| 2026-03-16 | Zod 3.x vs 4.x | 3.x | TECH-STACK.md is source of truth |
| 2026-03-16 | packages/api vs apps/api | apps/api | Matches actual folder structure |
| 2026-03-16 | Custom RLS vs auth.uid() | Custom (app.tenant_id) | Deliberate architectural choice |
