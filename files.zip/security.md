---
trigger: always_on
description: Security model, multi-tenancy rules, and token handling for Dashboard Link
---

# Dashboard Link — Security Rules

These rules are non-negotiable. They apply to every query, every endpoint, and every new feature.

## Multi-Tenancy — Absolute Rules

- Every database query MUST be scoped to `organization_id`
- Never query across organizations — one org must never see another's data
- Always filter by `organization_id` in application code, even when RLS is active
- RLS is the last line of defence, not the only one
- `organization_id` is ALWAYS derived from the JWT — never from request body or query params

```ts
// ✅ Correct — column is organization_id (not org_id)
const workers = await db
  .from('workers')
  .select('*')
  .eq('organization_id', organizationId)  // derived from JWT

// ❌ Wrong — missing org scope
const workers = await db.from('workers').select('*')

// ❌ Wrong — trusting client input
const orgId = c.req.query('org_id')  // never do this
```

## Token Rules

- Workers access dashboards via time-limited tokens only — never via login
- Token expiry: 1–24 hours, configurable per organization
- Never issue permanent tokens
- SHA-256 hash before storage — never store raw tokens
- `token_hash` column: always exactly 64 hex characters
- Token validation must check: expiry, revocation, org ownership, worker match
- Never expose raw token values in logs or API responses

```typescript
// ✅ Always hash before storing
const token = crypto.randomBytes(32).toString('hex')
const tokenHash = crypto.createHash('sha256').update(token).digest('hex')
// Store tokenHash, return token to client
```

## Worker Access Rules

- Workers have NO accounts, NO passwords, NO sessions
- Never create a worker authentication flow
- Never store worker credentials of any kind
- Worker identity chain: valid token → `dashboard_tokens` → `workers` → `organizations`

## API Endpoint Rules

- Every protected endpoint validates `organization_id` from JWT — not from request input
- Worker dashboard endpoints (`/api/dashboard/:token`) are public — no JWT, token-only
- Validate token ownership before returning any dashboard data
- All inputs validated with Zod schemas before touching business logic

## RLS Pattern (custom — not standard Supabase)

```typescript
// ✅ Set tenant context on every request in middleware/tenant.ts
await supabase.rpc('set_config', {
  setting: 'app.tenant_id',
  value: tenant.organizationId,
  is_local: true
});

// ❌ Do NOT use standard Supabase RLS pattern
// auth.uid() or auth.jwt() ->> 'organization_id' — these are WRONG for this codebase
```

## What Never Gets Exposed

| Secret | Rule |
|--------|------|
| `SUPABASE_SERVICE_KEY` | Server-side only, never in client code |
| `JWT_SECRET` | Server-side only |
| `MOBILE_MESSAGE_PASSWORD` | Server-side only |
| Raw dashboard tokens | Hash before storing, return once to client |
| OAuth access/refresh tokens | Encrypted at rest in `data_sources` table |

## New Table Security Checklist

Before any new table goes to production:
- [ ] RLS enabled: `ALTER TABLE x ENABLE ROW LEVEL SECURITY`
- [ ] Policy uses `current_setting('app.tenant_id', true)::uuid` pattern
- [ ] `organization_id` column exists, is NOT NULL, and has an index
- [ ] Application-level `organization_id` filter in all queries
- [ ] No query returns data without an org scope

## Banned Patterns

```typescript
// ❌ Never trust org from client
const orgId = body.organization_id

// ❌ Never use any type
const data: any = response

// ❌ Never hardcode secrets
const key = 'sk_live_abc123'

// ❌ Never bypass RLS without setting tenant context
await supabaseServiceRole.from('workers').select('*')  // RLS bypassed, no tenant set
```

## If Unsure

If uncertain whether a query is correctly org-scoped — stop and ask before proceeding.
Do not guess on security.
