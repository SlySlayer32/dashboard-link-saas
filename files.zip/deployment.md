---
trigger: glob
globs: ".github/**, **/vercel.json, **/railway.json, **/.env*, **/ENV*"
description: Deployment process, hosting, environment variables, and monitoring for Dashboard Link
---

# Dashboard Link — Deployment & Environment Rules

## Environments

| Environment | Admin URL | Worker URL | API URL |
|-------------|-----------|------------|---------|
| Local | localhost:5173 | localhost:5174 | localhost:3000 |
| Staging | TBD | TBD | TBD |
| Production | TBD | TBD | TBD |

**Status:** Not yet deployed. All production URLs are TBD.

## Hosting Plan

| Service | Provider | Status |
|---------|---------|--------|
| Frontend (admin + worker) | Vercel | Planned |
| Backend (API) | Railway | Planned |
| Database + Auth | Supabase | Active (dev) |

## Environment Variables — Never Commit Values

All variables documented in `/docs/5-dev-guide/ENV-VARIABLES.md`.

**Frontend (Vite — must be prefixed `VITE_`):**
```
VITE_SUPABASE_URL
VITE_SUPABASE_ANON_KEY
VITE_API_URL
```

**Backend (API):**
```
SUPABASE_URL
SUPABASE_ANON_KEY
SUPABASE_SERVICE_KEY      # ← server-side only, never expose to client
JWT_SECRET                # ← server-side only
DATABASE_URL              # optional direct connection
MOBILE_MESSAGE_USERNAME
MOBILE_MESSAGE_PASSWORD
MOBILE_MESSAGE_SENDER_ID
PORT                      # default 3000
NODE_ENV
CORS_ORIGIN
```

**Security rules for env vars:**
- Service role key (`SUPABASE_SERVICE_KEY`) never in client-side code
- Anon key is safe to expose in frontend (RLS protects data)
- Rotate immediately if accidentally committed
- Different keys for dev and production

## Database Migrations

```bash
# Apply migrations to production
npx supabase db push --project-ref <production-project-ref>

# Check migration status
npx supabase migration list

# Create new migration
npx supabase migration new <description>
```

Migrations are append-only — never edit existing files.

## CI/CD (Planned — not yet implemented)

`.github/workflows/` does not yet exist. When implementing:

Pipeline order: type-check → lint → test → deploy frontend → deploy backend

```yaml
# Planned jobs
- typecheck: pnpm typecheck
- lint: pnpm lint
- test: pnpm test:coverage
- deploy-frontend: Vercel action
- deploy-backend: Railway action
```

## Monitoring (planned before production launch)

| Component | Tool | Status |
|-----------|------|--------|
| Error tracking | Sentry | Not yet set up |
| Uptime monitoring | UptimeRobot (free) | Not yet set up |
| Performance | Supabase dashboard | Available now |

Health check endpoint target: `GET /api/health` — checks DB connection, returns `{ status: 'healthy' | 'unhealthy' }`.

Alert thresholds to configure:
- API error rate > 5% → critical
- SMS failure rate > 20% → critical
- API response time > 2s → high
- Database connections > 55 → high

## Backup Strategy

Supabase automatic backups:
- Free tier: daily, 7-day retention
- Pro tier ($25/month): daily + PITR (point-in-time recovery), 30-day retention

Manual backup before major schema changes:
```bash
npx supabase db dump > backup_$(date +%Y%m%d).sql
```

## Rollback Plan

**Frontend (Vercel):** Vercel Dashboard → Deployments → Promote previous deployment to production.
**Backend (Railway):** Railway Dashboard → Deployments → Redeploy previous version.
**Database:** Supabase Dashboard → Database → Backups → Restore. WARNING: restores overwrite current data. Prefer forward-fix migrations.
