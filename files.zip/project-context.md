---
trigger: always_on
description: Project identity, docs index, tech stack, and folder structure for Dashboard Link
---

# Dashboard Link — Project Context

## What This Product Is
- Multi-tenant SaaS platform
- Sends field workers a daily SMS containing a secure link
- Link opens a personalised mobile dashboard — no app, no login, no friction
- Managers configure once; system delivers daily automatically
- Primary market: cleaning service businesses, 5–50 workers, Australia

## Current Phase
MVP — Phase 1 (Months 1–3)
Goal: Prove 3–5 businesses prefer this over WhatsApp for daily worker comms

## Docs Index

| File | Purpose |
|------|---------|
| `/docs/CONTEXT.md` | Project primer — quick orientation |
| `/docs/1-overview/PRD.md` | Full product requirements |
| `/docs/1-overview/VISION.md` | North star and product vision |
| `/docs/1-overview/ROADMAP.md` | Phase 1/2/3 milestones |
| `/docs/2-architecture/ARCHITECTURE.md` | System architecture |
| `/docs/2-architecture/TECH-STACK.md` | Stack decisions — source of truth for versions |
| `/docs/2-architecture/DATABASE-SCHEMA.md` | Schema, RLS, indexes — source of truth for column names |
| `/docs/2-architecture/BACKEND.md` | Backend patterns and middleware |
| `/docs/2-architecture/FRONTEND.md` | Frontend architecture |
| `/docs/3-api/API-OVERVIEW.md` | API structure, auth, rate limits |
| `/docs/3-api/ENDPOINTS.md` | All endpoint signatures |
| `/docs/3-api/THIRD-PARTY-APIS.md` | External API limits and gotchas |
| `/docs/4-decisions/ADR/` | All architecture decision records |
| `/docs/5-dev-guide/SETUP.md` | Dev environment setup |
| `/docs/5-dev-guide/ENV-VARIABLES.md` | All environment variables |
| `/docs/5-dev-guide/SECURITY.md` | Security model and OWASP checklist |
| `/docs/5-dev-guide/TESTING.md` | Testing strategy and coverage targets |
| `/docs/5-dev-guide/DEPLOYMENT.md` | Deployment process and hosting |
| `/docs/6-product/FEATURES.md` | Feature build status — check before adding anything |
| `/docs/6-product/PRICING.md` | Plans, billing logic, limits |
| `/docs/6-product/USER-FLOWS.md` | User flows for all core scenarios |

## Locked Tech Stack
Do not suggest alternatives. These decisions are final and documented in `/docs/4-decisions/ADR/`.

| Layer | Decision | Version |
|-------|---------|---------|
| Backend framework | Hono.js | 4.x |
| Runtime | Node.js LTS | 18+ |
| Database | Supabase (PostgreSQL + RLS) | PostgreSQL 15+ |
| Frontend | Vite + React | Vite 5.x, React 18.x |
| Language | TypeScript | 5.x strict mode |
| Validation | Zod | 3.x — NOT 4.x |
| State (server) | TanStack Query | 5.x |
| State (global) | Zustand | 4.x |
| Monorepo | Turborepo + pnpm | latest |
| SMS provider | MobileMessage.com.au | AU only |
| Hosting (frontend) | Vercel | planned |
| Hosting (backend) | Railway | planned |

## Correct Folder Structure

```
apps/
  admin/        # Manager dashboard — desktop-first (Vite + React 18)
  worker/       # Worker dashboard — mobile-first, token access only
  api/          # Hono.js API server
packages/
  shared/       # Shared types, constants, utilities
  ui/           # Shared shadcn/ui components + Tailwind utilities
  plugins/      # Plugin adapters (Google Calendar, Airtable, Notion, manual)
  auth/         # Supabase Auth wrappers and JWT utilities
  database/     # Supabase client and database utilities
supabase/
  migrations/   # SQL migration files — append-only
  config.toml
docs/           # All documentation
.windsurf/
  rules/        # These rule files
```

**Note:** There is no `packages/api/`, `packages/sms/`, or `packages/tokens/` directory.
- SMS logic lives in `apps/api/src/services/sms.ts`
- Token logic lives in `apps/api/src/services/tokens.ts`

## Key Constraints
- Solo developer — every solution must be achievable alone
- Web-only — no native app, no App Store, no React Native
- Australia-first — SMS via MobileMessage.com.au (AU numbers only)
- No worker logins — access via time-limited token only
- No free tier for MVP — paid-only to validate willingness to pay
