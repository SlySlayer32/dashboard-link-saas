---
trigger: glob
globs: "**/*.sql, **/supabase/**, **/migrations/**, **/database/**"
description: Database patterns, RLS requirements, and query rules for Dashboard Link
---

# Dashboard Link — Database Rules

## Stack
- Supabase (PostgreSQL 15+)
- Row-Level Security (RLS) enforced at database level
- Application-level org scoping enforced in code as well (defence in depth)
- Migration files: `supabase/migrations/` — append-only, never edit existing files

## Column Name: `organization_id` (not `org_id`)

The actual schema uses `organization_id` on all tenant-scoped tables.
The previous rules files used `org_id` — that was wrong. Always use `organization_id`.

```ts
// ✅ Correct column name
.eq('organization_id', organizationId)

// ❌ Wrong — this column does not exist
.eq('org_id', orgId)
```

## Every Query Must Be Organization-Scoped

```ts
// ✅ Always filter by organization_id
const { data } = await supabase
  .from('workers')
  .select('*')
  .eq('organization_id', organizationId)

// ❌ Never query without org scope
const { data } = await supabase
  .from('workers')
  .select('*')
```

## RLS Pattern — CUSTOM (not standard Supabase)

This project uses a custom RLS pattern with a PostgreSQL session variable.
Standard Supabase patterns (`auth.uid()`, `auth.jwt()`) are WRONG here.

```sql
-- Our RLS policy pattern
CREATE POLICY "tenant_isolation" ON workers
  FOR ALL
  USING (organization_id = current_setting('app.tenant_id', true)::uuid);
```

The API must set the session variable on every request:
```typescript
// ✅ Required in tenant middleware before every query
await supabase.rpc('set_config', {
  setting: 'app.tenant_id',
  value: organizationId,
  is_local: true
});
```

**Why**: This is a deliberate choice for better control over service role operations.
See `/docs/2-architecture/DATABASE-SCHEMA.md` for full explanation.

## New Table Requirements

Every new table must have:

```sql
CREATE TABLE public.table_name (
  id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID    NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
  -- add columns here
);

-- Enable RLS
ALTER TABLE public.table_name ENABLE ROW LEVEL SECURITY;

-- RLS policy using session variable (NOT auth.uid())
CREATE POLICY "tenant_isolation" ON public.table_name
  FOR ALL
  USING (organization_id = current_setting('app.tenant_id', true)::uuid);

-- Required index
CREATE INDEX ON public.table_name(organization_id);

-- Auto-update trigger for updated_at
CREATE TRIGGER update_table_name_updated_at
  BEFORE UPDATE ON public.table_name
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
```

## Tables Reference

| Table | Purpose | Key columns |
|-------|---------|-------------|
| `organizations` | Top-level tenant | `id`, `name`, `slug`, `plan` |
| `users` | Admin users (managers) | `id`, `organization_id`, `email`, `role` |
| `workers` | Field workers | `id`, `organization_id`, `full_name`, `phone_number` |
| `data_sources` | Plugin configs | `id`, `organization_id`, `plugin_id`, `status` |
| `dashboard_tokens` | Time-limited access tokens | `id`, `token_hash`, `worker_id`, `organization_id`, `expires_at` |
| `sms_logs` | SMS delivery history | `id`, `organization_id`, `worker_id`, `status` |
| `access_logs` | Dashboard open tracking | `id`, `organization_id`, `worker_id`, `token_id` |

## Deletion Strategy — Hard Deletes Only

No `deleted_at` columns anywhere. Permanent deletion only.
See `/docs/4-decisions/ADR/002-hard-deletes-over-soft-deletes.md` for rationale.

- Dependent data: `ON DELETE CASCADE`
- Audit logs: `ON DELETE SET NULL` (preserve history, nullify FK)

## Validation Constraints (from actual schema)

```sql
phone_number  -- E.164 format: /^\+[1-9]\d{1,14}$/
email         -- standard email regex
token_hash    -- exactly 64 hex characters (SHA-256)
plugin_id     -- must be one of: 'google-calendar', 'airtable', 'notion', 'manual'
plan          -- must be one of: 'free', 'pro', 'enterprise'
status        -- per-table enum, see schema
token_expiry  -- 1–24 hours only
```

## Migration Rules

- All schema changes go through migration files — never edit schema directly in Supabase UI
- Name format: `YYYYMMDDHHMMSS_description.sql`
- Never edit existing migration files — write a new one
- Expand-contract pattern for destructive changes: add new column → migrate data → remove old column

## Supabase Client Rules

- Always use the server-side Supabase client for API routes — never the anon client directly
- Never expose the service role key client-side
- Service role bypasses RLS — always set `app.tenant_id` before using it for tenant queries
- Typed client — reference generated types from `packages/database/src/types.ts`
