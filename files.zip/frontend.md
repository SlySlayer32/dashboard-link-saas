---
trigger: glob
globs: "apps/admin/**, apps/worker/**, packages/ui/**"
description: Frontend architecture, state management, component rules, and worker dashboard requirements for Dashboard Link
---

# Dashboard Link — Frontend Rules

## Apps Overview

| App | Path | Audience | Design focus |
|-----|------|----------|-------------|
| Admin dashboard | `apps/admin/` | Managers | Desktop-first |
| Worker dashboard | `apps/worker/` | Field workers | Mobile-first, 320px+, touch targets 44×44px min |
| Shared UI | `packages/ui/` | Both | shadcn/ui + Tailwind utilities |

## Stack (locked — do not suggest alternatives)

- **Vite 5.x + React 18.x + TypeScript 5.x** strict mode
- Routing: React Router 6.x
- Forms: React Hook Form 7.x + Zod 3.x resolver
- Icons: lucide-react only
- Dates: date-fns (never moment.js)
- Classes: clsx + tailwind-merge

## State Management — Strict Separation

**Zustand 4.x** — global app state only:
- Auth state (JWT, user profile)
- Organization context (org ID, settings)
- UI state (sidebar open/closed, theme)

**TanStack Query 5.x** — all server data. **Must use v5 object syntax** (v4 positional syntax is a breaking error):

```typescript
// ✅ v5 correct
useQuery({
  queryKey: ['workers', organizationId],
  queryFn: () => fetchWorkers(organizationId),
  staleTime: 5 * 60 * 1000,
})
useMutation({
  mutationFn: createWorker,
  onSuccess: () => queryClient.invalidateQueries({ queryKey: ['workers'] }),
})

// ❌ v4 wrong — will not work with v5
useQuery(['workers'], () => fetchWorkers())
useMutation(() => createWorker(), { onSuccess: ... })
```

**useState** — form inputs, modals, dropdowns, component-local state only.

## Worker Dashboard — Non-Negotiable Requirements

These are core to the product value proposition. Never degrade them:

1. **No login, no account** — token URL is the only access method
2. **Today-first** — always opens to today, zero date navigation required
3. **Single page** — all critical info visible without scrolling on mobile
4. **< 2 second load on 4G** — this is a PRD requirement
5. **Screenshot-able** — fully useful after initial load; no lazy-loading of critical content
6. **Offline-tolerant** — once loaded, dashboard works without further network requests
7. **Works on Day 1** — zero setup for casual/rotating staff

## Styling Rules

- Tailwind CSS utility-first — no custom CSS files unless absolutely unavoidable
- shadcn/ui components from `packages/ui/src/components/`
- Responsive prefix convention: `sm:` `md:` `lg:` `xl:`
- No inline styles — use Tailwind classes
- Dark mode: follow shadcn/ui conventions

## Component Conventions

Split a component when:
- It exceeds 200 lines
- Logic is reused in 2+ places  
- It has 3+ distinct responsibilities

Required structure order:
```typescript
// 1. Imports
// 2. Types / interfaces
// 3. Component function
//   a. Hooks (all hooks first, before any logic)
//   b. Derived state / computed values
//   c. Event handlers
//   d. Render (return)
```

One component per file. Co-locate tests: `WorkerCard.test.tsx` next to `WorkerCard.tsx`.
Export from index: `components/index.ts` for clean imports.

## File Naming

| Thing | Convention | Example |
|-------|-----------|---------|
| React components | PascalCase | `WorkerCard.tsx` |
| Hooks | camelCase with `use` prefix | `useTokenValidation.ts` |
| Utilities | kebab-case | `format-phone.ts` |
| Tests | same name + `.test` | `WorkerCard.test.tsx` |
| Pages | PascalCase | `Dashboard.tsx` |

## Import Conventions

Order:
1. External packages (React, third-party)
2. Internal packages (`@dashboard-link/*`)
3. Relative imports (`./`, `../`)
4. Type imports

Use `@/` alias for within-app imports. Use `@dashboard-link/ui`, `@dashboard-link/shared` for cross-package.
Never use `../../../` deep relative paths.

## Error Boundaries

- Every major component subtree needs an Error Boundary
- Production: show generic user-friendly message only — no stack traces
- Development: show full error details

## Forms

Never use HTML `<form>` elements. Always use React Hook Form:

```typescript
// ✅ Correct
const { register, handleSubmit } = useForm({ resolver: zodResolver(schema) })
<button onClick={handleSubmit(onSubmit)}>Save</button>

// ❌ Wrong
<form onSubmit={handleSubmit}>
```

## API Layer

All API calls go through TanStack Query hooks in `apps/*/src/api/`.
Never call `fetch` or `axios` directly in components.

## Banned Patterns

- `any` type
- `var`
- HTML `<form>` tags
- Suppressed TypeScript errors
- `index` as React list key — use stable IDs
- Prop mutation
- TanStack Query v4 positional syntax
- Direct `fetch` in components (use query hooks)
- moment.js (use date-fns)
- Inline styles (use Tailwind classes)
