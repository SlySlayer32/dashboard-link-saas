---
trigger: glob
globs: "apps/api/src/routes/**, docs/3-api/**"
description: API endpoint signatures, response shapes, pagination, and third-party API limits for Dashboard Link
---

# Dashboard Link — API Rules

## Base URLs
- Local dev: `http://localhost:3000/api`
- Production: TBD (not yet deployed)

## Authentication

**Admin endpoints:** JWT via Supabase Auth
- Header: `Authorization: Bearer <token>`
- JWT payload contains: `user_id`, `organization_id`
- Token expiry: ~1 hour access token, 7 days refresh (Supabase Auth defaults)

**Worker dashboard endpoints:** Token in URL — no JWT
- `GET /api/dashboard/:token` — validated via `token_hash` lookup in `dashboard_tokens`
- `POST /api/tokens/validate` — public endpoint

## Response Shape — Always This, No Exceptions

```typescript
// Success
{
  success: true,
  data: T,
  meta: {
    requestId: string,
    timestamp: string  // ISO 8601
  }
}

// Paginated success
{
  success: true,
  data: T[],
  meta: {
    pagination: { page: number, limit: number, total: number, totalPages: number, hasMore: boolean },
    requestId: string,
    version: string
  }
}

// Error
{
  success: false,
  error: {
    code: string,       // stable code — clients handle by code, not message
    message: string,    // human-readable
    details?: object    // optional, e.g. field-level validation errors
  }
}
```

## Standard Error Codes

| Code | HTTP | When |
|------|------|------|
| `UNAUTHORIZED` | 401 | Invalid or expired JWT |
| `FORBIDDEN` | 403 | Valid JWT, insufficient permissions |
| `NOT_FOUND` | 404 | Resource does not exist |
| `VALIDATION_ERROR` | 400 | Zod schema validation failed |
| `BAD_REQUEST` | 400 | General bad request |
| `CONFLICT` | 409 | Resource already exists (duplicate phone, etc.) |
| `RATE_LIMITED` | 429 | Too many requests (use `RATE_LIMITED`, not `RATE_LIMIT_EXCEEDED`) |
| `INTERNAL_ERROR` | 500 | Unexpected server error |

## Pagination — Page + Limit (not raw offset)

```typescript
// Query params accepted
?page=2&limit=20     // page min 1, limit max 100, defaults: page=1, limit=20

// Offset calculated internally
const offset = (page - 1) * limit

// Never accept ?offset= as a direct query param
```

Endpoints with pagination: `GET /api/tokens`, `GET /api/sms/logs`

## Endpoint Reference

### Workers
```
GET    /api/workers           list, params: limit, offset
POST   /api/workers           create, body: { full_name, phone_number, calendar_email? }, returns 201
PUT    /api/workers/:id       update, body: same as POST (all optional)
DELETE /api/workers/:id       hard delete, body: { confirm: "DELETE" } required
```

### Plugins
```
GET    /api/plugins           list configured plugins
POST   /api/plugins           connect, body: { plugin_id, config }
PUT    /api/plugins/:id       update config
DELETE /api/plugins/:id       disconnect
POST   /api/plugins/:id/sync  manual sync trigger
```

### SMS
```
POST   /api/sms/send          body: { worker_ids: UUID[], token_expiry_hours?: number }
GET    /api/sms/logs          paginated, filters: worker_id, status
```

### Tokens
```
POST   /api/tokens/generate   body: { worker_id: UUID, expiry_hours?: number (1-24, default 8) }
POST   /api/tokens/validate   PUBLIC — no auth, body: { token: string }
POST   /api/tokens/revoke     body: { token_id: UUID }
```

### Dashboard (public, token-based)
```
GET    /api/dashboard/:token  PUBLIC — no JWT, returns worker dashboard data
```

## Validation Schemas (Zod 3.x)

```typescript
// Worker
{ 
  full_name: z.string().min(1).max(100),
  phone_number: z.string().regex(/^\+[1-9]\d{1,14}$/),
  calendar_email: z.string().email().optional()
}

// Plugin
{ 
  plugin_id: z.enum(['google-calendar', 'airtable', 'notion', 'manual']),
  config: z.object({}).passthrough()
}

// SMS send
{ 
  worker_ids: z.array(z.string().uuid()),
  token_expiry_hours: z.number().min(1).max(24).optional()
}

// Token generate
{ 
  worker_id: z.string().uuid(),
  expiry_hours: z.number().min(1).max(24).optional()
}
```

## Third-Party API Limits

| Service | Rate limit | Notes |
|---------|-----------|-------|
| MobileMessage.com.au | 100 SMS/min | AU only (+61), 2–3¢/SMS, free virtual number |
| Google Calendar | 1M queries/day, 10 QPS/user | OAuth scope: `calendar.readonly` |
| Airtable | 5 req/sec per base | Max 100 records per request, paginate for more |
| Notion | 3 req/sec avg, 100 req/min burst | No native webhooks — polling only |
| Supabase (free tier) | 60 DB connections max | Connection pooling needed at scale |

## Rate Limiting (required before production launch)

```
General API:    100 req/min per organization
SMS sending:    10 req/min per organization
Token gen:      20 req/min per organization
Plugin sync:    30 req/hour per organization
```

429 response headers: `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset`, `Retry-After`

## Webhook Endpoints — Phase 3 Only

Do not build these until Phase 3. Do not stub or scaffold them now.

```
POST /api/webhooks/google-calendar   — Phase 3
POST /api/webhooks/airtable          — Phase 3
POST /api/webhooks/notion            — Phase 3
POST /api/webhooks/sms-delivery      — Phase 3
```

All will require signature verification when built.

## Versioning

- MVP: no versioning (`/api/...`)
- Post-MVP: URL-based (`/api/v1/...`)
- Non-breaking changes (new fields, new endpoints) — add to existing version
- Breaking changes — require new version
