---
trigger: glob
globs: "**/*.test.ts, **/*.test.tsx, **/vitest.config.*, **/test/**"
description: Testing strategy, tools, coverage targets, and MSW setup for Dashboard Link
---

# Dashboard Link — Testing Rules

## Tools
- **Vitest** — unit and integration tests (not Jest)
- **Testing Library** — React component testing
- **Supertest** — HTTP API endpoint testing
- **MSW (Mock Service Worker)** — mock external API calls in tests

## Test Priorities (high → low)
1. Multi-tenant isolation and RLS enforcement
2. Token generation, validation, and expiry
3. API endpoints (request → validation → service → response)
4. SMS delivery and error handling
5. Plugin adapters
6. UI components (mostly manual)

## Coverage Targets

| Category | Target | What's included |
|----------|--------|----------------|
| Security-critical code | 90–95% | `middleware/tenant.ts`, `services/tokens.ts`, auth middleware |
| Business logic (services) | 80% | Dashboard, SMS, plugin services |
| API endpoints (routes) | 80% | Route handlers, validation |
| Overall project | 65–75% | Acceptable for MVP |

## What Must Always Be Tested
- Multi-tenant isolation — one org cannot see another's data
- Token validation — expired/revoked/invalid tokens are rejected
- Phone number validation — E.164 format enforced
- RLS policies — cross-tenant queries blocked
- Error handling — correct status codes and error codes returned
- Organization ID always comes from JWT, never request body

## What We Intentionally Don't Test
- Third-party libraries (React, Hono, Supabase internals)
- UI styling and visual layout
- Simple getters/setters with no business logic
- Database migration files
- Framework routing code

## MSW Setup

MSW handlers live in `apps/api/src/test/mocks/handlers.ts`.
Available mock handlers:
- `POST https://api.mobilemessage.com.au/v1/send` — validates +61 format, returns mock message ID
- `GET https://www.googleapis.com/calendar/v3/...` — returns 2 mock events
- `POST https://oauth2.googleapis.com/token` — mock OAuth flow
- `GET https://api.airtable.com/v0/:baseId/:tableId` — returns 2 mock records
- `POST https://api.notion.com/v1/databases/:id/query` — returns 1 mock page

Override for error scenarios:
```typescript
import { server } from '@/test/mocks/server'
import { http, HttpResponse } from 'msw'

server.use(
  http.post('https://api.mobilemessage.com.au/v1/send', () =>
    HttpResponse.json({ error: 'Failed' }, { status: 500 })
  )
)
```

Handlers reset automatically between tests via `server.resetHandlers()` in `setup.ts`.

## Test Commands

```bash
pnpm test                                    # all tests
pnpm test:watch                              # watch mode
pnpm test:coverage                           # with coverage report
pnpm --filter @dashboard-link/api test       # API tests only
pnpm --filter @dashboard-link/admin test     # Admin tests only
pnpm typecheck                               # TypeScript check (not tests, but required)
pnpm lint                                    # ESLint check
```

## Tenant Isolation Test (must pass before any release)

A dedicated test that:
1. Creates two separate organizations
2. Adds workers to each
3. Verifies each can only see their own data
4. Verifies SQL injection attempts are blocked by RLS
5. Cleans up test data

Run via: `pnpm --filter @dashboard-link/api test:isolation`

## Test File Conventions

- Co-locate with source: `WorkerCard.test.tsx` next to `WorkerCard.tsx`
- API integration tests: `apps/api/src/routes/*.test.ts`
- Unit tests: `apps/api/src/services/*.test.ts`
- Test data: never use real phone numbers or email addresses
