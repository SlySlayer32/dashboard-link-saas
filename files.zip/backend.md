---
trigger: glob
globs: "apps/api/**, packages/plugins/**, packages/auth/**, packages/database/**"
description: Backend architecture, middleware order, error handling, and service patterns for Dashboard Link
---

# Dashboard Link — Backend Rules

## Framework
- **Hono.js 4.x** on Node.js 18+ LTS, TypeScript 5.x strict mode
- Entry point: `apps/api/src/index.ts`
- Never suggest Express, Fastify, or Next.js API routes — Hono is locked

## Middleware Order (always in this exact sequence)

```
1. honoLogger           — log all requests
2. CORS                 — handle preflight
3. middleware/tenant.ts — extract + validate org context from JWT
4. Route-specific cache — if applicable
5. Route handler
6. app.onError          — sanitize error responses
```

## Request Lifecycle

```typescript
// Reading request data
const body   = await c.req.json()          // JSON body
const page   = c.req.query('page')         // single query param
const id     = c.req.param('id')           // URL param
const token  = c.req.header('Authorization')

// After zValidator middleware — use this, not c.req.json()
const validated = c.req.valid('json')      // type-safe validated body

// Setting/getting context between middleware
c.set('userId', payload.sub)
c.set('organizationId', payload.organization_id)
const orgId = c.get('organizationId')
```

## Error Handling

Prefer `HTTPException` from Hono for all HTTP errors:

```typescript
// ✅ Preferred
import { HTTPException } from 'hono/http-exception'
throw new HTTPException(404, { message: 'Worker not found' })
throw new HTTPException(401, { message: 'Invalid token' })
```

Custom error classes in `apps/api/src/lib/errors.ts` exist — use them only when `HTTPException` can't cover the case.

Standard error codes (stable, clients depend on these):
`UNAUTHORIZED` | `FORBIDDEN` | `NOT_FOUND` | `VALIDATION_ERROR` | `RATE_LIMITED` | `INTERNAL_ERROR` | `CONFLICT` | `BAD_REQUEST`

All responses must follow this shape — no exceptions:
```typescript
// Success
{ success: true, data: T, meta: { requestId: string, timestamp: string } }

// Error
{ success: false, error: { code: string, message: string, details?: object } }
```

## Input Validation

Use `@hono/zod-validator` (Zod 3.x) on every endpoint that accepts a body:

```typescript
import { zValidator } from '@hono/zod-validator'
import { z } from 'zod'

const schema = z.object({
  full_name: z.string().min(1).max(100),
  phone_number: z.string().regex(/^\+[1-9]\d{1,14}$/),
})

app.post('/api/workers',
  zValidator('json', schema),
  async (c) => {
    const body = c.req.valid('json')  // type-safe, already validated
  }
)
```

## Service Layer Structure

```
apps/api/src/
  routes/         # Route handlers only — no business logic here
    workers.ts
    plugins.ts
    sms.ts
    tokens.ts
    dashboard.ts
    webhooks.ts   # ← use this file (not webhook-service.ts)
  middleware/
    auth.ts       # JWT validation
    tenant.ts     # Sets app.tenant_id session variable
    rate-limit.ts # Per-org rate limiting
  services/       # Business logic lives here
    dashboard.ts
    sms.ts
    tokens.ts     # ← canonical token service
    plugins.ts
    webhookService.ts  # ← canonical webhook service (camelCase, no hyphen)
  lib/
    db.ts         # Supabase client
    errors.ts     # Custom error classes
    logger.ts     # Structured logging — use this, never console.log
```

## File Conflicts — Canonical Versions

| Use this | Not this | Action |
|----------|----------|--------|
| `services/webhookService.ts` | `services/webhook-service.ts` | Delete `webhook-service.ts` after confirming no imports |
| `routes/webhooks.ts` | Inline webhook block in `routes/v1.ts` | Remove from `v1.ts`, register `routes/webhooks.ts` |
| `services/tokens.ts` | Any other token file | Consolidate |

## Database Access Pattern

All DB access goes through repository classes — no direct Supabase calls in route handlers:

```typescript
// ✅ Correct
const workerRepo = getWorkerRepository()
const worker = await workerRepo.findById(workerId)

// ❌ Wrong — direct DB call in route handler
const { data } = await supabase.from('workers').select('*').eq('id', workerId)
```

Repository factories: `getWorkerRepository()`, `getOrganizationRepository()`, `getDashboardRepository()`, `getSMSLogRepository()`

## Plugin Adapters

Vendor SDK calls live ONLY in `packages/plugins/src/adapters/`:
- `google-calendar.ts` — Google Calendar API
- `airtable.ts` — Airtable API
- `notion.ts` — Notion API
- `manual.ts` — manual entry

Route handlers and services call adapters — never SDK methods directly.
Plugin registry: `packages/plugins/src/registry.ts`

## SMS Service

- AU-only: +61 numbers only (E.164 format)
- Provider: MobileMessage.com.au
- Rate limit: 100 SMS/minute (provider-level)
- Every send must be logged in `sms_logs` table
- Cost tracking: 2–3¢/SMS

## Token Service

- SHA-256 hash before storage — raw token returned once to client, never stored
- `token_hash` = 64 hex chars always
- Expiry: 1–24 hours (org default from `default_token_expiry_hours`)
- Cleanup: Supabase scheduled function removes tokens past expiry + 24h

## Pagination Pattern

```typescript
// ✅ Accept page + limit, compute offset internally
const page   = parseInt(c.req.query('page')  ?? '1')   // min 1
const limit  = parseInt(c.req.query('limit') ?? '20')  // max 100
const offset = (page - 1) * limit

// ❌ Never accept raw offset as a query param
```

Response must include `meta.pagination: { page, limit, total, totalPages, hasMore }`.

## Rate Limits (implement before production)

| Endpoint group | Limit |
|---------------|-------|
| General API | 100 req/min per org |
| SMS sending | 10 req/min per org |
| Token generation | 20 req/min per org |
| Plugin sync | 30 req/hour per org |

Rate limit error code: `RATE_LIMITED` (not `RATE_LIMIT_EXCEEDED`)

## Banned Patterns

- `any` type — use `unknown` or proper types
- Hardcoded secrets — env vars only, see `/docs/5-dev-guide/ENV-VARIABLES.md`
- `console.log` — use `lib/logger.ts` structured logging
- Direct Supabase calls in route handlers — use repositories
- Vendor SDK calls outside `packages/plugins/src/adapters/`
- Trusting `organization_id` from client input
- Bypassing RLS without setting tenant context
- `var` — use `const` / `let`
