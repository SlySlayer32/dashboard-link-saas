# .windsurf/rules — File Index

## Files in This Folder

| File | Trigger | Purpose |
|------|---------|---------|
| `project-context.md` | always_on | Product identity, correct folder structure, locked tech stack |
| `before-building.md` | always_on | Session checklist, communication style, naming conventions |
| `scope.md` | always_on | All 49 components + MVP boundaries — what is and isn't being built |
| `security.md` | always_on | Multi-tenancy rules, token handling, banned patterns |
| `conflicts.md` | always_on | Duplicate file decisions — read when two files do the same thing |
| `database.md` | glob: sql/migrations | Correct column names, RLS pattern, table template |
| `backend.md` | glob: apps/api | Middleware order, services, error handling, file conflicts |
| `frontend.md` | glob: apps/admin/worker/packages/ui | State management, component rules, worker dashboard requirements |
| `api.md` | glob: routes/docs/3-api | Endpoint signatures, response shapes, rate limits |
| `testing.md` | glob: test files | Test tools, coverage targets, MSW setup |
| `deployment.md` | glob: .github/env files | Hosting, env vars, CI/CD, monitoring, backups |

## ❌ File to Delete

`specify-rules.md` — this was auto-generated and contains errors:
- Wrong Zod version (4.x instead of 3.x)
- Wrong project structure (packages/api/ instead of apps/api/)
- Duplicate technology lines
- No triggers configured

**Delete it.** All its content is superseded by the files above.
